
from flask import Flask, request, jsonify
import json
import os
from datetime import datetime
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

DATA_FILE = 'distractions.json'

if not os.path.exists(DATA_FILE):
    with open(DATA_FILE, 'w') as f:
        json.dump([], f)

CATEGORIES = {
    "Social Media": ["instagram", "facebook", "twitter", "youtube", "tiktok"],
    "Phone Call": ["call", "phone", "talk","chatting"],
    "Browsing": ["google", "reddit", "browse", "netflix","amazon prime"],
    "Other": []
}

def categorize(text):
    text = text.lower()
    for category, keywords in CATEGORIES.items():
        for word in keywords:
            if word in text:
                return category
    return "Other"

@app.route("/log", methods=["POST"])
def log_distraction():
    data = request.json
    text = data.get("text", "")
    category = categorize(text)

    with open(DATA_FILE, 'r') as f:
        logs = json.load(f)

    logs.append({
        "text": text,
        "category": category,
        "timestamp": datetime.now().isoformat()
    })

    with open(DATA_FILE, 'w') as f:
        json.dump(logs, f)

    return jsonify({"message": "Logged!", "category": category})

@app.route("/stats", methods=["GET"])
def stats():
    with open(DATA_FILE, 'r') as f:
        logs = json.load(f)

    counts = {}
    for log in logs:
        cat = log["category"]
        counts[cat] = counts.get(cat, 0) + 1

    return jsonify(counts)

@app.route("/logs", methods=["GET"])
def get_logs():
    with open(DATA_FILE, 'r') as f:
        logs = json.load(f)
    return jsonify(logs)

if __name__ == "__main__":
    app.run(debug=True)
