
import React, { useState } from 'react';
import axios from 'axios';

const BACKEND_URL = "http://127.0.0.1:5000";

function DistractionForm({ onLog }) {
  const [text, setText] = useState("");

  const handleSubmit = e => {
    e.preventDefault();
    axios.post(`${BACKEND_URL}/log`, { text })
      .then(res => {
        alert(`Logged as: ${res.data.category}`);
        setText("");
        onLog();
      });
  };

  return (
    <form onSubmit={handleSubmit} style={{ margin: '20px' }}>
      <input 
        type="text" 
        placeholder="What distracted you?" 
        value={text}
        onChange={e => setText(e.target.value)}
        style={{ padding: '10px', width: '300px' }}
        required
      />
      <button style={{ padding: '10px 20px', marginLeft: '10px' }}>Log</button>
    </form>
  );
}

export default DistractionForm;
