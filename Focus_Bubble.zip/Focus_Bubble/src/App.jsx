
import React, { useState, useEffect } from 'react';
import DistractionForm from './DistractionForm.jsx';
import BubbleChart from './BubbleChart.jsx';
import axios from 'axios';

const BACKEND_URL = "http://127.0.0.1:5000";

function App() {
  const [stats, setStats] = useState({});

  const fetchStats = () => {
    axios.get(`${BACKEND_URL}/stats`).then(res => {
      setStats(res.data);
    });
  };

  useEffect(() => {
    fetchStats();
  }, []);

  return (
    <div className="App" style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Focus Bubbles</h1>
      <DistractionForm onLog={fetchStats} />
      <BubbleChart stats={stats} />
    </div>
  );
}

export default App;
