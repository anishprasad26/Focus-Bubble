
import React from 'react';
import { motion } from 'framer-motion';

const colors = {
  "Social Media": "#FF6B6B",
  "Phone Call": "#4ECDC4",
  "Browsing": "#FFD93D",
  "Other": "#C7CEEA"
};

function BubbleChart({ stats }) {
  const bubbles = Object.entries(stats).map(([category, count]) => (
    <motion.div 
      key={category}
      animate={{ scale: 1 + count * 0.1 }}
      transition={{ type: "spring", stiffness: 200 }}
      style={{
        width: 50 + count * 10,
        height: 50 + count * 10,
        borderRadius: '50%',
        backgroundColor: colors[category] || '#ccc',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        margin: '10px',
        color: '#fff',
        fontWeight: 'bold'
      }}
    >
      {category}
    </motion.div>
  ));

  return (
    <div style={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap' }}>
      {bubbles.length > 0 ? bubbles : <p>No data yet. Start logging distractions!</p>}
    </div>
  );
}

export default BubbleChart;
